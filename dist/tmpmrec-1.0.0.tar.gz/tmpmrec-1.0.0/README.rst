# Tpmrec: a topic model and recommer system framework

## Requirements

Minimum requirements:
-Python 2.7+
-NumPy 1.9+

You can install Tpmrec from the source code:
```
python setup.py install
```

